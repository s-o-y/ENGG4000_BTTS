/*
 * File:   main.c
 * Author: Zoe Devries
 *
 * Created on March 4, 2024, 4:49 PM
 */

// DSPIC33EV32GM002 Configuration Bit Settings
// FSEC
#pragma config BWRP = OFF               // Boot Segment Write-Protect Bit (Boot Segment may be written)
#pragma config BSS = DISABLED           // Boot Segment Code-Protect Level bits (No Protection (other than BWRP))
#pragma config BSS2 = OFF               // Boot Segment Control Bit (No Boot Segment)
#pragma config GWRP = OFF               // General Segment Write-Protect Bit (General Segment may be written)
#pragma config GSS = DISABLED           // General Segment Code-Protect Level bits (No Protection (other than GWRP))
#pragma config CWRP = OFF               // Configuration Segment Write-Protect Bit (Configuration Segment may be written)
#pragma config CSS = DISABLED           // Configuration Segment Code-Protect Level bits (No Protection (other than CWRP))
#pragma config AIVTDIS = DISABLE        // Alternate Interrupt Vector Table Disable Bit  (Disable Alternate Vector Table)

// FBSLIM
#pragma config BSLIM = 0x1FFF           // Boot Segment Code Flash Page Address Limit Bits (Enter Hexadecimal value)

// FOSCSEL
#pragma config FNOSC = FRCDIVN          // Initial oscillator Source Selection Bits (Internal Fast RC (FRC) Oscillator with postscaler)
#pragma config IESO = OFF               // Two Speed Oscillator Start-Up Bit (Start up device with user selected oscillator source)

// FOSC
#pragma config POSCMD = NONE            // Primary Oscillator Mode Select Bits (Primary Oscillator disabled)
#pragma config OSCIOFNC = ON            // OSC2 Pin I/O Function Enable Bit (OSC2 is general purpose digital I/O pin)
#pragma config IOL1WAY = ON             // Peripheral Pin Select Configuration Bit (Allow Only One reconfiguration)
#pragma config FCKSM = CSDCMD           // Clock Switching Mode Bits (Both Clock Switching and Fail-safe Clock Monitor are disabled)
#pragma config PLLKEN = OFF             // PLL Lock Enable Bit (Clock switch will not wait for the PLL lock signal)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler Bits (1:32,768)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler Bit (1:128)
#pragma config FWDTEN = ON              // Watchdog Timer Enable Bits (WDT Enabled)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable Bit (Watchdog timer in Non-Window Mode)
#pragma config WDTWIN = WIN25           // Watchdog Window Select Bits (WDT Window is 25% of WDT period)

// FPOR
#pragma config BOREN0 = ON              // Brown Out Reset Detection Bit (BOR is Enabled)

// FICD
#pragma config ICS = PGD1               // ICD Communication Channel Select Bits (Communicate on PGEC1 and PGED1)

// FDMTINTVL
#pragma config DMTIVTL = 0xFFFF         // Lower 16 Bits of 32 Bit DMT Window Interval (Enter Hexadecimal value)

// FDMTINTVH
#pragma config DMTIVTH = 0xFFFF         // Upper 16 Bits of 32 Bit DMT Window Interval (Enter Hexadecimal value)

// FDMTCNTL
#pragma config DMTCNTL = 0xFFFF         // Lower 16 Bits of 32 Bit DMT Instruction Count Time-Out Value (Enter Hexadecimal value)

// FDMTCNTH
#pragma config DMTCNTH = 0xFFFF         // Upper 16 Bits of 32 Bit DMT Instruction Count Time-Out Value (Enter Hexadecimal value)

// FDMT
#pragma config DMTEN = ENABLE           // Dead Man Timer Enable Bit (Dead Man Timer is Enabled and cannot be disabled by software)

// FDEVOPT
#pragma config PWMLOCK = OFF            // PWM Lock Enable Bit (PWM registers may be written without key sequence)
#pragma config ALTI2C1 = OFF            // Alternate I2C1 Pins Selection Bit (I2C1 mapped to SDA1/SCL1 pins)

// FALTREG
#pragma config CTXT1 = NONE             // Interrupt Priority Level (IPL) Selection Bits For Alternate Working Register Set 1 (Not Assigned)
#pragma config CTXT2 = NONE             // Interrupt Priority Level (IPL) Selection Bits For Alternate Working Register Set 2 (Not Assigned)

#include <xc.h>
#include <math.h>
#include <stdint.h>
#include <time.h>
#include <stdio.h>

#define DEVICE_ADDR 0x6B    // LSM9DS1 Device Address
#define REFERENCE_G 0x0B 	// (R/W) Angular rate sensor reference value register for digital high-pass filter (r/w).
#define INT1_CTRL 0x0C		// (R/W) INT1_A/G pin control register
#define INT2_CTRL 0x0D		// (R/W)INT2_A/G pin control register.
#define WHO_AM_I 0x0F		// (R) Who am i? That's one secret I'll never tell xoxo Gossip Girl
#define CTRL_REG1_G 0x10	// (R/W) Angular rate sensor Control Register 1. 
#define CTRL_REG2_G 0x11	// (R/W) Angular rate sensor Control Register 2. 
#define CTRL_REG3_G 0x12	// (R/W) Angular rate sensor Control Register 3. 
#define ORIENT_CFG_G 0x13	// (R/W) Angular rate sensor sign and orientation register 
#define INT_GEN_SRC_G 0x14	// (R) Angular rate sensor interrupt source register. !!!!!!!!!!! CONFIGURE
#define OUT_X_L_G 0x18		// (R) Angular rate sensor pitch axis (X) angular rate output register. The value is expressed as a 16-bit word in two?s complement.
#define OUT_X_H_G 0x19      // (R) The higher of the above statement
#define OUT_Y_L_G 0x1A      // (R) Angular rate sensor pitch axis (Y) angular rate output register. The value is expressed as a 16-bit word in two?s complement.
#define OUT_Y_H_G 0x1B      // (R) The higher of the above statement
#define OUT_Z_L_G 0x1C      // (R) Angular rate sensor pitch axis (Z) angular rate output register. The value is expressed as a 16-bit word in two?s complement.
#define OUT_Z_H_G 0x1D      // (R) The higher of the above statement
#define CTRL_REG4 0x1E		// (R/W) Only enable bit 3 (x axis gyroscope enable)
#define CTRL_REG8 0x22		// (R/W) Bit 0 (sw reset), bit 2 (if_add_inc disable!!!! ask opinion), bit 6 (BDU to 1 so that it only gets updated when LSB is read)
#define CTRL_REG9 0x23 		// (R/W) you could do smth with CTRL_REG9 with the DRDY_mask_bit to havve a timer to tell you if data is available)
#define FIFO_CTRL 0x2E      // (R/W)

#define GYRO_SCALE 245

#define FCY 3740000         // Fosc = 7.48MHz, Fcy = Fosc/2 = 3.74MHz

// Calculate the time base (PHASE1 calculation):
// PHASEx = Fosc/(FPWM*PWM_Input_Clock_Prescaler)
// - Fosc = FRC tuned to 7.48MHz and then FRCDIVN (FNOSC in configuration bits)
// - FPWM = 50 Hz for motor control (determined externally)
// - PWM_Input_Clock_Prescaler = 64 (PCLKDIV bits in PTCON2)
#define TIME_BASE_CALC 2337.5
#define CLOCKS_PER_SECOND 7480000

#define MAGNETO_ADDR 0x1E   // magnetometer addr

// GLOBAL VARIABLES FOR THE TIMER INTERRUPT
uint16_t imuSpeed;
uint16_t imuSpeedLower;
//uint8_t speedSign;
float imuFloat;
float dutyCycleCalc;

int flag = 1; // will be used to make the motor go the opposite direction

// Setup Functions
void oscSetup(void) {
    // Note that Fosc is configured as FRC with DIV by N in configuration bits  
    OSCTUN = 0b011111;              // FRC is tuned to 7.48 MHz   
    CLKDIVbits.FRCDIV0 = 0;         // These bits mean N = 1
    CLKDIVbits.FRCDIV1 = 0;
    CLKDIVbits.FRCDIV2 = 0;
}
void pwmInitialize(float timeBaseCalc) {
    // PWM MODULE 1 SETUP
    // General parameters of PWM1
    PWMCON1bits.MDCS = 0;   // PDC1 register provides duty cycle information for PWM1 generator
    PWMCON1bits.ITB = 1;    // PHASE1 register provides time base period for PWM1 generator
    PWMCON1bits.CAM = 0;    // Edge-Aligned mode is enabled
    PWMCON1bits.IUE = 0;    // 0 = Updates to the active PDC1/PHASE1 registers are synchronized to the PWMx period boundary
    PTCON2bits.PCLKDIV = 0b110; // PWM1 Input Clock Pre-scaler is Divide-by-64    
    
    // Initialize Period and Duty Cycle of PWM1
    PHASE1 = timeBaseCalc;      // Frequency of PWM = 50 Hz, Time base = 2337.5
    PDC1 = timeBaseCalc*0.075;  // Duty cycle = 7.5%, Ton = 1500 us, Motor Stopped 
    
    
    // Enable PWM1 Module
    PTCONbits.PTEN = 1;         // PWM1 Generator is enabled
}
void i2cInitialize(void) {
    // Configure I2C lines as digital
    TRISBbits.TRISB5 = 1; // SDA is digital output
    TRISBbits.TRISB6 = 1; // SCL is digital output
    
    // GET THE CLOCK CONTROL AND FILL OUT I2C1BRG REGISTER
    I2C1CON1bits.DISSLW = 0; 
    I2C1CON1bits.ACKDT = 1;         // the device will send a NACK when told to    
    //I2C1BRG = 15;                 // Baud rate generator for FCY = 3.74MHz, FSCL = 100kHz, delay = 120ns
    I2C1BRG = 13.95;                // Baud rate generator for FCY = 3.74MHz, FSCL = 100kHz, delay = 120ns    
    I2C1ADDbits.ADD = DEVICE_ADDR;  // the imu's address
    I2C1CON1bits.I2CEN = 1;         // enable the I2C1 module 
    //__delay_us(0.150);            // delay 150 ns after the initialization before sending any data !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}

// I2C Code
void i2cIdle() {
    while((I2C1CON1bits.ACKEN || I2C1CON1bits.RCEN || I2C1CON1bits.PEN || I2C1CON1bits.RSEN || I2C1CON1bits.SEN)) {} 
    // is start, repeated start, stop, receive enable, acknowledge enable idle (all those) and acknowledge bit 0
    // OR is there a transmit in progress
}
void i2cStart(void) {
    i2cIdle();              // make sure line is idle
    I2C1CON1bits.SEN = 1;   // Complete the start condition 
    }
void i2cRepeatedStart(void) {
    i2cIdle();              // make sure line is idle
    I2C1CON1bits.RSEN = 1;  // Complete the repeated start condition 
}
void i2cStop() {
    i2cIdle();              // make sure line is idle
    I2C1CON1bits.PEN = 1;   // complete stop condition 
}
void i2cCmndAddr(uint8_t slaveAddr, uint8_t command) {
    // Waits for the line to be idle, writes one byte to the IMU, waits for slave acknowledge
    // Command bit it 1 for read, 0 for write
    i2cIdle();  // make sure line is idle
    I2C1ADDbits.ADD = slaveAddr;
    I2C1TRNbits.I2CTXDATA = (slaveAddr << 1) + command;  // put the data to transmit into the buffer
    while(I2C1STATbits.TBF != 0) {}     // while the buffer is not empty 
    while(I2C1STATbits.ACKSTAT != 0) {} // while slave has not acknowledged
}
void i2cWriteSub(uint8_t subAddr) {
    // Waits for the line to be idle, writes one byte to the IMU, waits for slave acknowledge
    i2cIdle();  // make sure line is idle
    I2C1TRNbits.I2CTXDATA = subAddr;    // put the data to transmit into the buffer
    while(I2C1STATbits.TBF != 0) {}     // while the buffer is not empty 
    while(I2C1STATbits.ACKSTAT != 0) {} // while slave has not acknowledged
}
uint8_t i2cRead() {
    // Waits for the line to be idle, reads one byte from the IMU, sends NACK, returns the data
    // Requires that I2C1CON1bits.ACKDT is set beforehand to indicate if it is the beginning or end of the transmission
    uint8_t dataReceived;                   // create a variable to store the data
    i2cIdle();                              // make sure line is idle to set RCEN
    I2C1CON1bits.RCEN = 1;                  // the master is in receive mode and starts the BRG (automatically falls after slave transmission)
    while (I2C1STATbits.RBF != 1) {}        // wait until 8 bits have been read 
    dataReceived = I2C1RCVbits.I2CRXDATA;   // dataReceived = value in the buffer read from IMU (RBF is cleared)
    i2cIdle();                              // the bus must be idle for the ACKEN bit to be set (ACKEN is cleared in hardware)
    I2C1CON1bits.ACKEN = 1;                 // send the appropriate acknowledge                 
    return dataReceived;                    // return the received data
}
void i2cWriteData(uint8_t transmitData) {
    // Waits for the line to be idle, writes one byte to the IMU, waits for slave acknowledge
    i2cIdle();  // make sure line is idle
    I2C1TRNbits.I2CTXDATA = transmitData;  // put the data to transmit into the buffer
    while(I2C1STATbits.TBF != 0) {}  // while the buffer is not empty 
    while(I2C1STATbits.ACKSTAT != 0) {}  // while slave has not acknowledged
}
void i2cHighLvlWrite(uint8_t  registerAddr, uint8_t data) {
    i2cStart();
    i2cCmndAddr(DEVICE_ADDR, 0);    // Write to LSM9DS1
    i2cWriteSub(registerAddr);              // IMU Register specified by user
    i2cWriteData(data);             // Send the new value of the register
    i2cStop();  
}
uint8_t i2cHighLvlRead(uint8_t registerAddr) {
    uint8_t check; 
    i2cStart();
    i2cCmndAddr(DEVICE_ADDR, 0);
    i2cWriteSub(registerAddr);          // read the data in the who_am_i register       
    i2cRepeatedStart();
    i2cCmndAddr(DEVICE_ADDR, 1);    //
    check = i2cRead();      // read the data in the who_am_i register       
    i2cStop();
    return check;
}
void imuInitialize(void) {
    //uint8_t data;
    uint8_t check;
    
    // Check Sequence    
    check = i2cHighLvlRead(WHO_AM_I);
         
    // Software reset
    //i2cHighLvlWrite(CTRL_REG8, 0x01); // WILL CLEAR THE SOFTWARE ON THE IMU
    
    i2cHighLvlWrite(REFERENCE_G, 0x00); // Angular rate sensor reference value register for digital high-pass filter (r/w).
    i2cHighLvlWrite(INT1_CTRL, 0x00); 	// Angular rate sensor reference value register for digital high-pass filter (r/w).
    i2cHighLvlWrite(INT2_CTRL,0x00);    // INT2_A/G pin control register.
    i2cHighLvlWrite(CTRL_REG1_G,0x60);  // Angular rate sensor Control Register 1. ODR {Hz} = 119 w/ cutoff = 38
    i2cHighLvlWrite(CTRL_REG2_G,0x00);  // Angular rate sensor Control Register 2. 
    i2cHighLvlWrite(CTRL_REG3_G, 0x00); // Angular rate sensor Control Register 3. (SET LOW POWER MODE)
    i2cHighLvlWrite(ORIENT_CFG_G, 0x00);// Angular rate sensor sign and orientation register 
    i2cHighLvlWrite(CTRL_REG4, 0x08);   // Only enable bit 3 (x axis gyroscope enable)
    i2cHighLvlWrite(CTRL_REG8,0x00);    // Actual: no auto increments; Optional Changes: Bit 0 (sw reset), bit 6 (BDU to 1 so that it only gets updated when LSB is read)
    i2cHighLvlWrite(CTRL_REG9,0x00);    // you could do smth with CTRL_REG9 with the DRDY_mask_bit to havve a timer to tell you if data is available)
    i2cHighLvlWrite(FIFO_CTRL, 0xC0);   // Tell it what mode you want: Continuous

}

// Conversions
float twoCompGuyPreNegated(uint16_t guy) { 
    float ans;
    if ((guy & 0x8000) == 0x0000) {   // the number is negative therefore the motor must do the opposite
        ans = - (float) (~guy+1);
    }
    else { // the number is positive therefore the motor must do the opposite
        guy = ~guy + 1;
        ans = (float) -guy;
    }
    return -1*ans;
}
float calculateCounter(float imu) {
    // Note the lower duty cycles for the motor are -ve CW according to the datasheet. However, that is looking out of the servo.
    // This means that it is CCw looking into the motor
    float dutyCycle;
    imu = imu*5/GYRO_SCALE;                                // based on Olivia's calculations 
    if ((imu > 0) && (imu <= 150)) {            // if the imu is rotating CW, actuate the motor CCW (opposite direction)
        dutyCycle = 6*powf(10,-5)*imu+0.0754;   // See the excel for the data and the trend-line fit
    } else if ((imu < 0) && (imu >= -150)) {
        dutyCycle = 7*powf(10,-5)*imu+0.0747;   // See the excel for the data and the trend-line fit
    } else if (imu > 150) {
        dutyCycle = 6*powf(10,-5)*(-150)+0.0754;
    } else if (imu < -150) {
        dutyCycle = 7*powf(10,-5)*150+0.0747;    
    } else {
        dutyCycle = 0.075;
    }
    return dutyCycle;
}

int main(void) {      
    // -------------------------------------------------------------------------
    // MODULES SETUP
    oscSetup();                     // Setup FRCDIVN = 7.48 MHz, FCY = 3.74MHz
    pwmInitialize(TIME_BASE_CALC);  // Initialize the PWM1 module
    i2cInitialize();                // Initialize the I2C1 module
    imuInitialize();                // Initialize the IMU via I2C
        
    while(1) {
        imuSpeedLower = i2cHighLvlRead(OUT_X_L_G);  // Angular rate sensor pitch axis (X) angular rate output register. The value is expressed as a 16-bit word in two?s complement.
        imuSpeed = i2cHighLvlRead(OUT_X_H_G);       // The higher of the above statement
        imuSpeed = (imuSpeed << 8) + imuSpeedLower; // shift the gyroscope data into the uint16_t

        // STEP 2. Convert data from two's complement
        imuFloat = twoCompGuyPreNegated(imuSpeed);

        // STEP 3. Calculate corresponding duty cycle
        //dutyCycleCalc = calculateCounter(imuFloat); 
        
        // STEP 4. Actuate the motor 
        if (flag == 0) {
            flag = 1;
            dutyCycleCalc = 0.0643;
        }
        else {
            flag = 0;
            dutyCycleCalc = 0.08505;
        } 

        PDC1 = TIME_BASE_CALC * dutyCycleCalc; 

        for (int i = 0; i< 2000; i++) {}
    }
    
    return 0;
}

